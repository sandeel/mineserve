<?php
namespace Wrench\Exception;

use Wrench\Exception\Exception as WrenchException;

class PayloadException extends WrenchException
{
}
